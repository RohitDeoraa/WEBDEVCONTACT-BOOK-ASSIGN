// src/utils/storage.js
export const loadContacts = () => JSON.parse(localStorage.getItem('contacts')) || [];

export const saveContacts = (contacts) => {
  localStorage.setItem('contacts', JSON.stringify(contacts));
};
