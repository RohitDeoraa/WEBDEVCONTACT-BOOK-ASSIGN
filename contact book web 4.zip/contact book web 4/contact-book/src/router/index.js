// src/router/index.js
import { createRouter, createWebHistory } from 'vue-router';
import ContactList from '../views/ContactList.vue';
import ContactDetail from '../views/ContactDetail.vue';
import AddEditContact from '../views/AddEditContact.vue';

const routes = [
  { path: '/', name: 'Home', component: ContactList },
  { path: '/contact/:id', name: 'ContactDetail', component: ContactDetail, props: true },
  { path: '/add', name: 'AddContact', component: AddEditContact },
  { path: '/edit/:id', name: 'EditContact', component: AddEditContact, props: true },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
