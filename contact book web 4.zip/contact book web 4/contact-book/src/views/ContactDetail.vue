<template>
    <div class="container">
      <h2>{{ contact.firstName }} {{ contact.lastName }}</h2>
      <p><strong>Email:</strong> {{ contact.email }}</p>
      <router-link :to="{ name: 'EditContact', params: { id: contact.id } }">
        <button>Edit</button>
      </router-link>
      <button @click="deleteContact">Delete</button>
      <router-link to="/">
        <button>Back to Contacts</button>
      </router-link>
    </div>
  </template>
  
  <script>
  import { loadContacts, saveContacts } from '../utils/storage';
  
  export default {
    props: ['id'],
    data() {
      return {
        contact: loadContacts().find(c => c.id === parseInt(this.id)),
      };
    },
    methods: {
      deleteContact() {
        const contacts = loadContacts().filter(c => c.id !== parseInt(this.id));
        saveContacts(contacts);
        this.$router.push('/');
      },
    },
  };
  </script>
  