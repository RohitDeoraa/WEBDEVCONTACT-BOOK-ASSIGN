<template>
    <div class="container">
      <h2>{{ isEditMode ? 'Edit' : 'Add' }} Contact</h2>
      <form @submit.prevent="submitForm">
        <input v-model="contact.firstName" placeholder="First Name" required />
        <input v-model="contact.lastName" placeholder="Last Name" required />
        <input v-model="contact.email" placeholder="Email" required />
        <button type="submit">{{ isEditMode ? 'Update' : 'Add' }} Contact</button>
      </form>
      <router-link to="/">
        <button>Back to Contacts</button>
      </router-link>
    </div>
  </template>
  
  <script>
  import { loadContacts, saveContacts } from '../utils/storage';
  
  export default {
    props: ['id'],
    data() {
      const contacts = loadContacts();
      return {
        isEditMode: !!this.id,
        contact: this.id
          ? contacts.find(c => c.id === parseInt(this.id))
          : { id: Date.now(), firstName: '', lastName: '', email: '' },
      };
    },
    methods: {
      submitForm() {
        let contacts = loadContacts();
        if (this.isEditMode) {
          contacts = contacts.map(c => (c.id === this.contact.id ? this.contact : c));
        } else {
          contacts.push(this.contact);
        }
        saveContacts(contacts);
        this.$router.push({ name: 'ContactDetail', params: { id: this.contact.id } });
      },
    },
  };
  </script>
  