<template>
    <div class="container">
      <h1>Contact List</h1>
      <input v-model="searchQuery" placeholder="Search contacts..." />
      <ul>
        <li v-for="contact in filteredContacts" :key="contact.id">
          <router-link :to="{ name: 'ContactDetail', params: { id: contact.id } }">
            {{ contact.firstName }} {{ contact.lastName }}
          </router-link>
          <button @click="viewDetails(contact.id)">View</button>
        </li>
      </ul>
      <router-link to="/add">
        <button>Add New Contact</button>
      </router-link>
    </div>
  </template>
  
  <script>
  import { loadContacts } from '../utils/storage';
  
  export default {
    data() {
      return {
        searchQuery: '',
        contacts: loadContacts(),
      };
    },
    computed: {
      filteredContacts() {
        return this.contacts
          .filter(contact =>
            `${contact.firstName} ${contact.lastName}`
              .toLowerCase()
              .includes(this.searchQuery.toLowerCase())
          )
          .sort((a, b) => a.lastName.localeCompare(b.lastName));
      },
    },
    methods: {
      viewDetails(id) {
        this.$router.push({ name: 'ContactDetail', params: { id } });
      },
    },
  };
  </script>
  